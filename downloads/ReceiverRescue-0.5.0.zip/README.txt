Receiver Rescue 0.5.0 — experimental Windows launcher.

Extract fully and keep manifests beside ReceiverRescue.exe. Read SECURITY.md and docs/PROTECTED-LAUNCH.md before any recovery. 0.5.0 security integration test: owner reported PASS. No physical recovery was performed with this version. Do not disable Windows security features.
